SENTENCE = 'sentence'
OVERALL = 'overall'
ENROLLED = 'enrolled'
SUBTITLES = 'subtitles'
SKILLS = 'skills'
TOPIC = 'topic'
PROVIDER = 'provider'

SEARCH_FORM_FIELDS = [
    SENTENCE,
    OVERALL,
    ENROLLED,
    SUBTITLES,
    SKILLS,
    TOPIC,
    PROVIDER
]


'''CPC_VALUES = [
    ('A', 'Human Necessitites'),
    ('B', 'Performing Operations; Transportin'),
    ('C', 'Chemistry; Metallurg'),
    ('D', 'Textiles'),
    ('E', 'Fixed Construction'),
    ('F', 'Mechanical Engineerin'),
    ('G', 'Physics'),
    ('H', 'Electricity'),
    ('Y', 'General Tagging of New Technological Developments'),
]'''
